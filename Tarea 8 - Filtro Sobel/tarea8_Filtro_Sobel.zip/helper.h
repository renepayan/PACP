#ifndef HELPER_H
#define HELPER_H

#include "imagen.h"
unsigned char * reservarMemoria( uint32_t width, uint32_t height );
double *reservarMemoriaMascara();
#endif