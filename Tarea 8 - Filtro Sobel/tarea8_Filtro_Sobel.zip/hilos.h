#ifndef HILOS_H
#define HILOS_H

#include "imagen.h"

void* funcionHilo(void* arg);
#endif